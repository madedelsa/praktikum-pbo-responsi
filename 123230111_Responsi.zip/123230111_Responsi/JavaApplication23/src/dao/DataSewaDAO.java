package dao;

import interfaces.SewaMobil;
import koneksi.Connector;
import model.DataSewa;
import java.sql.*;
import java.util.*;
import java.util.logging.Logger;
import java.util.logging.Level;

public class DataSewaDAO implements SewaMobil{
    Connection conn = Connector.getConnection();
    
    String insert = "INSERT INTO sewa_mobil (id, nama, kontak, jenis_mobil, durasi, status) VALUES (NULL, ?, ?, ?, ?. ?)";
    String select = "SELECT * FROM sewa_mobil";
    String update = "UPDATE sewa_mobil SET nama = ?, kontak = ?, jenis_mobil = ?, durasi = ?, status = ? WHERE id = ?";
    String delete = "DELETE FROM sewa_mobil WHERE id = ?";
    
    public DataSewaDAO() {
        conn = Connector.getConnection();
    }
    
    @Override
    public void insert(DataSewa ds) {
        PreparedStatement statement = null;
        
        try {
            statement = conn.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, ds.getNama());
            statement.setString(2, ds.getKontak());
            statement.setString(3, ds.getJenisMobil());
            statement.setInt(4, ds.getDurasi());
            statement.setString(5, ds.getStatus());
            
            ResultSet rs = statement.getGeneratedKeys();
            while (rs.next()) {
                ds.setId(1);               
            }
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try {
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<DataSewa> getAll(DataSewa s) {
        List<DataSewa> ds = null;
        try {
            ds = new ArrayList<DataSewa>();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(select);
            
            while (rs.next()) {
                DataSewa sewa = new DataSewa();
                
                sewa.setId(rs.getInt("id"));
                sewa.setNama(rs.getString("nama"));
                sewa.setKontak(rs.getString("kontak"));
                sewa.setJenisMobil(rs.getString("jenis_mobil"));
                sewa.setDurasi(rs.getInt("durasi"));
                sewa.setKontak(rs.getString("status"));
                
                ds.add(sewa);
            }           
        } catch (SQLException e) {
            Logger.getLogger(DataSewa.class.getName()).log(Level.SEVERE, null, e);
        }
        return ds;
    }

    @Override
    public void update(DataSewa ds) {
        PreparedStatement statement = null;
        
        try {
            statement = conn.prepareStatement(update);
            statement.setString(1, ds.getNama());
            statement.setString(2, ds.getKontak());
            statement.setString(3, ds.getJenisMobil());
            statement.setInt(4, ds.getDurasi());
            statement.setString(5, ds.getStatus());
            
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try {
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void delete(int id) {
        PreparedStatement statement = null;
        try {
            statement = conn.prepareStatement(delete);
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (Exception e) {
          e.printStackTrace();
        } finally{
            try {
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
