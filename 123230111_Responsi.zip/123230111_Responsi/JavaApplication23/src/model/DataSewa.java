package model;

public class DataSewa {
    private int id;
    private String nama;
    private String kontak;
    private String jenis_mobil;
    private int durasi;
    private int total_biaya;
    private String status;
    
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }
    public String getNama(){
        return nama;
    }
    public void setNama(String nama){
        this.nama = nama;
    }
    public String getKontak(){
        return kontak;
    }
    public void setKontak(String kontak){
        this.kontak = kontak;
    }
    public String getJenisMobil(){
        return jenis_mobil;
    }
    public void setJenisMobil(String jenis_mobil){
        this.jenis_mobil = jenis_mobil;
    }
    public int getDurasi(){
        return durasi;
    }
    public void setDurasi(int durasi){
        this.durasi = durasi;
    }
    public String getStatus(){
        return status;
    }
    public void setStatus(String status){
        this.status = this.status;
    }
    
    public void hitungTotalBiaya(){
        this.total_biaya = durasi * 300000;
    }
}
