package koneksi;
import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {
    private static final String db_url = "jdbc:mysql://localhost/sewa_mobil";
    private static final String user = "root";
    private static final String pass = "";
    
    public static Connection getConnection(){
        try{
            return DriverManager.getConnection(db_url, user, pass);
        } catch(Exception e){
            System.out.println("Koneksi gagal: " + e.getMessage());
            return null;
        }
    }
}
