package interfaces;

import  model.DataSewa;
import java.util.List;

public interface SewaMobil {
    public  void insert(DataSewa ds);
    public  List<DataSewa> getAll(DataSewa ds);
    public  void update(DataSewa ds);
    public  void delete(int id);    
}
